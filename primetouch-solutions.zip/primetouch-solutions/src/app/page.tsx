import Link from "next/link";
import ServiceCard from "@/components/ServiceCard";
import { siteConfig } from "@/lib/config";

export default function HomePage() {
  return (
    <>
      {/* Hero */}
      <section className="bg-navy text-white">
        <div className="max-w-7xl mx-auto section-padding text-center">
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4 leading-tight">
            Professional Laundry, Cleaning & Business Support in Sokoto
          </h1>
          <p className="text-lg sm:text-xl text-gold mb-2">{siteConfig.slogan}</p>
          <p className="text-gray-300 max-w-2xl mx-auto mb-8">
            Reliable laundry services, home & office cleaning, and practical business support 
            for residents and organisations across Sokoto Metropolis.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact" className="btn-gold">
              Book a Service
            </Link>
            <a
              href={`https://wa.me/${siteConfig.whatsapp}`}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-outline border-white text-white hover:bg-white hover:text-navy"
            >
              Chat on WhatsApp
            </a>
          </div>
        </div>
      </section>

      {/* Services overview */}
      <section className="section-padding bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-2xl md:text-3xl font-bold text-navy text-center mb-10">
            Our Services
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <ServiceCard
              title="Laundry & Dry Cleaning"
              description="Professional washing, ironing and specialist dry cleaning through trusted partners. Pickup and delivery available within service areas."
              href="/laundry"
            />
            <ServiceCard
              title="Home & Office Cleaning"
              description="Thorough residential and commercial cleaning tailored to your needs in Sokoto Metropolis."
              href="/cleaning"
            />
            <ServiceCard
              title="Consultancy & Business Support"
              description="Practical administrative support, document preparation and basic business planning for small businesses."
              href="/consultancy"
            />
          </div>
        </div>
      </section>

      {/* Why choose us */}
      <section className="section-padding">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-navy mb-6">
            Why Choose PrimeTouch Solutions?
          </h2>
          <div className="grid sm:grid-cols-3 gap-6 text-left">
            <div className="p-4">
              <h3 className="font-semibold text-gold mb-2">Local Focus</h3>
              <p className="text-gray-600 text-sm">We understand Sokoto and serve the metropolis with reliable, timely service.</p>
            </div>
            <div className="p-4">
              <h3 className="font-semibold text-gold mb-2">Clear Communication</h3>
              <p className="text-gray-600 text-sm">Easy booking via form or WhatsApp. Transparent process from enquiry to completion.</p>
            </div>
            <div className="p-4">
              <h3 className="font-semibold text-gold mb-2">Quality Focus</h3>
              <p className="text-gray-600 text-sm">We prioritise careful handling of your clothes, home and business needs.</p>
            </div>
          </div>
          <Link href="/contact" className="btn-primary mt-8 inline-flex">
            Request a Free Quote
          </Link>
        </div>
      </section>
    </>
  );
}
