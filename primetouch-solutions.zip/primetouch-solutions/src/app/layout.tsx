import type { Metadata } from "next";
import "../styles/globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import WhatsAppButton from "@/components/WhatsAppButton";
import { siteConfig } from "@/lib/config";

export const metadata: Metadata = {
  title: {
    default: "PrimeTouch Solutions | Laundry, Cleaning & Business Support in Sokoto",
    template: "%s | PrimeTouch Solutions",
  },
  description:
    "Professional laundry services, dry cleaning, home & office cleaning, and business support in Sokoto Metropolis, Nigeria. Pickup & delivery available. Excellence in Every Touch.",
  keywords: [
    "laundry services in Sokoto",
    "laundry pickup and delivery in Sokoto",
    "home cleaning services in Sokoto",
    "office cleaning in Sokoto",
    "business support services in Sokoto",
    "dry cleaning Sokoto",
  ],
  openGraph: {
    title: "PrimeTouch Solutions – Excellence in Every Touch",
    description: "Trusted laundry, cleaning and business support services in Sokoto.",
    locale: "en_NG",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="font-sans">
        <Header />
        <main className="min-h-screen">{children}</main>
        <Footer />
        <WhatsAppButton />
      </body>
    </html>
  );
}
