export const siteConfig = {
  name: "PrimeTouch Solutions",
  slogan: "Excellence in Every Touch.",
  location: "Sokoto Metropolis, Sokoto State, Nigeria",

  // === UPDATE THESE WITH YOUR REAL DETAILS ===
  phone: "+234 XXX XXX XXXX",          // e.g. +234 803 123 4567
  whatsapp: "234XXXXXXXXXX",           // no + or spaces, e.g. 2348031234567
  email: "info@primetouchsolutions.ng", // change to your real email
  hours: "Monday – Saturday: 8:00 AM – 6:00 PM",

  // Formspree form ID (get free at formspree.io)
  formspreeEndpoint: "https://formspree.io/f/YOUR_FORM_ID",

  // Service areas (edit freely)
  serviceAreas: ["Sokoto Metropolis", "Surrounding areas (subject to confirmation)"],

  // Example prices – clearly marked as unconfirmed
  pricingNote: "All prices below are examples only and subject to confirmation. Final rates depend on volume, location, and specific requirements. Request a free quote for accurate pricing.",
};
