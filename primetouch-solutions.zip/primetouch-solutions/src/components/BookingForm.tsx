"use client";

import { useState } from "react";
import { siteConfig } from "@/lib/config";

export default function BookingForm() {
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [errorMsg, setErrorMsg] = useState("");

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setStatus("loading");
    setErrorMsg("");

    const form = e.currentTarget;
    const data = new FormData(form);

    try {
      const res = await fetch(siteConfig.formspreeEndpoint, {
        method: "POST",
        body: data,
        headers: { Accept: "application/json" },
      });

      if (res.ok) {
        setStatus("success");
        form.reset();
      } else {
        const json = await res.json();
        setErrorMsg(json.error || "Something went wrong. Please try again or contact us on WhatsApp.");
        setStatus("error");
      }
    } catch {
      setErrorMsg("Network error. Please check your connection or message us on WhatsApp.");
      setStatus("error");
    }
  }

  if (status === "success") {
    return (
      <div className="bg-green-50 border border-green-200 rounded-lg p-6 text-center">
        <h3 className="text-xl font-semibold text-green-800 mb-2">Thank you!</h3>
        <p className="text-green-700">
          Your enquiry has been received. We will contact you shortly on the phone number you provided.
        </p>
        <button
          onClick={() => setStatus("idle")}
          className="mt-4 text-sm text-navy underline"
        >
          Send another enquiry
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      <div>
        <label htmlFor="name" className="block text-sm font-medium text-navy mb-1">
          Full Name *
        </label>
        <input
          type="text"
          id="name"
          name="name"
          required
          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gold focus:border-transparent"
          placeholder="Your full name"
        />
      </div>

      <div>
        <label htmlFor="phone" className="block text-sm font-medium text-navy mb-1">
          Phone Number *
        </label>
        <input
          type="tel"
          id="phone"
          name="phone"
          required
          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gold focus:border-transparent"
          placeholder="e.g. 0803 123 4567"
        />
      </div>

      <div>
        <label htmlFor="service" className="block text-sm font-medium text-navy mb-1">
          Service Required *
        </label>
        <select
          id="service"
          name="service"
          required
          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gold focus:border-transparent"
        >
          <option value="">Select a service</option>
          <option value="Laundry">Laundry Services</option>
          <option value="Dry Cleaning">Dry Cleaning</option>
          <option value="Home Cleaning">Home Cleaning</option>
          <option value="Office Cleaning">Office Cleaning</option>
          <option value="Pickup & Delivery">Laundry Pickup & Delivery</option>
          <option value="Consultancy">Consultancy / Business Support</option>
          <option value="Quote Request">Request a Quotation</option>
          <option value="Other">Other</option>
        </select>
      </div>

      <div>
        <label htmlFor="location" className="block text-sm font-medium text-navy mb-1">
          Your Location in Sokoto *
        </label>
        <input
          type="text"
          id="location"
          name="location"
          required
          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gold focus:border-transparent"
          placeholder="e.g. Gwiwa, Runjin Sambo, etc."
        />
      </div>

      <div>
        <label htmlFor="date" className="block text-sm font-medium text-navy mb-1">
          Preferred Date
        </label>
        <input
          type="date"
          id="date"
          name="preferred_date"
          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gold focus:border-transparent"
        />
      </div>

      <div>
        <label htmlFor="message" className="block text-sm font-medium text-navy mb-1">
          Additional Instructions
        </label>
        <textarea
          id="message"
          name="message"
          rows={4}
          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gold focus:border-transparent"
          placeholder="Any special requests or details..."
        />
      </div>

      {status === "error" && (
        <p className="text-red-600 text-sm">{errorMsg}</p>
      )}

      <button
        type="submit"
        disabled={status === "loading"}
        className="w-full btn-primary disabled:opacity-60"
      >
        {status === "loading" ? "Sending..." : "Submit Enquiry"}
      </button>

      <p className="text-xs text-gray-500 text-center">
        By submitting you agree to be contacted by PrimeTouch Solutions regarding your enquiry.
        Form submissions are sent securely via Formspree to the business email.
      </p>
    </form>
  );
}
