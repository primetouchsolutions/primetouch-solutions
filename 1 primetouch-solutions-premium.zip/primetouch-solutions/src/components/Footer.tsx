import Link from "next/link";
import { siteConfig } from "@/lib/config";

export default function Footer() {
  return (
    <footer className="bg-navy text-white">
      <div className="max-w-7xl mx-auto section-padding">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-bold text-gold mb-3">{siteConfig.name}</h3>
            <p className="text-sm text-gray-300 mb-2">{siteConfig.slogan}</p>
            <p className="text-sm text-gray-300">{siteConfig.location}</p>
          </div>

          <div>
            <h4 className="font-semibold text-gold mb-3">Quick Links</h4>
            <ul className="space-y-2 text-sm">
              <li><Link href="/laundry" className="hover:text-gold">Laundry & Dry Cleaning</Link></li>
              <li><Link href="/cleaning" className="hover:text-gold">Home & Office Cleaning</Link></li>
              <li><Link href="/consultancy" className="hover:text-gold">Consultancy</Link></li>
              <li><Link href="/fashion-beauty" className="hover:text-gold">Fashion & Beauty</Link></li>
              <li><Link href="/pricing" className="hover:text-gold">Pricing</Link></li>
              <li><Link href="/contact" className="hover:text-gold">Book a Service</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-gold mb-3">Contact</h4>
            <ul className="space-y-2 text-sm text-gray-300">
              <li>Phone: <a className="hover:text-gold" href={`tel:${siteConfig.phone}`}>{siteConfig.phone}</a></li>
              <li>WhatsApp: <a className="hover:text-gold" href={`https://wa.me/${siteConfig.whatsapp}`} target="_blank" rel="noopener noreferrer">+{siteConfig.whatsapp}</a></li>
              <li>Email: {siteConfig.email}</li>
              <li>{siteConfig.hours}</li>
            </ul>
          </div>
        </div>

        <div className="border-t border-navy-light mt-10 pt-6 text-center text-sm text-gray-400">
          © {new Date().getFullYear()} {siteConfig.name}. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
