import Link from "next/link";

interface Props {
  title: string;
  description: string;
  href: string;
}

export default function ServiceCard({ title, description, href }: Props) {
  return (
    <div className="bg-white border border-gray-100 rounded-xl shadow-sm hover:shadow-md transition-shadow p-6 flex flex-col">
      <h3 className="text-xl font-semibold text-navy mb-3">{title}</h3>
      <p className="text-gray-600 flex-grow mb-4">{description}</p>
      <Link href={href} className="text-gold font-medium hover:underline">
        Learn more →
      </Link>
    </div>
  );
}
