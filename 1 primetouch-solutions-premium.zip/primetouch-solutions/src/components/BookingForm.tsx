"use client";

import { siteConfig } from "@/lib/config";

export default function BookingForm() {
  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const data = new FormData(form);
    const fields = [
      `Hello ${siteConfig.name}, I would like to make an enquiry.`,
      `Name: ${data.get("name")}`,
      `Phone: ${data.get("phone")}`,
      `Service: ${data.get("service")}`,
      `Location: ${data.get("location")}`,
      `Preferred date: ${data.get("preferred_date") || "Not specified"}`,
      `Additional details: ${data.get("message") || "None"}`,
    ];
    const url = `https://wa.me/${siteConfig.whatsapp}?text=${encodeURIComponent(fields.join("\n"))}`;
    window.open(url, "_blank", "noopener,noreferrer");
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      <div><label htmlFor="name" className="block text-sm font-medium text-navy mb-1">Full Name *</label><input type="text" id="name" name="name" required autoComplete="name" className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gold focus:border-transparent" placeholder="Your full name" /></div>
      <div><label htmlFor="phone" className="block text-sm font-medium text-navy mb-1">Phone Number *</label><input type="tel" id="phone" name="phone" required autoComplete="tel" className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gold focus:border-transparent" placeholder="e.g. 0813 248 1687" /></div>
      <div><label htmlFor="service" className="block text-sm font-medium text-navy mb-1">Service Required *</label><select id="service" name="service" required className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gold focus:border-transparent"><option value="">Select a service</option><option value="Laundry">Laundry Services</option><option value="Dry Cleaning">Dry Cleaning</option><option value="Home Cleaning">Home Cleaning</option><option value="Office Cleaning">Office Cleaning</option><option value="Pickup & Delivery">Laundry Pickup & Delivery</option><option value="Consultancy">Consultancy Services</option><option value="Fashion & Clothing">Fashion & Clothing</option><option value="Cosmetics & Beauty">Cosmetics & Beauty</option><option value="Quote Request">Request a Quotation</option><option value="Other">Other</option></select></div>
      <div><label htmlFor="location" className="block text-sm font-medium text-navy mb-1">Your Location in Sokoto *</label><input type="text" id="location" name="location" required className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gold focus:border-transparent" placeholder="Your area or neighbourhood" /></div>
      <div><label htmlFor="date" className="block text-sm font-medium text-navy mb-1">Preferred Date</label><input type="date" id="date" name="preferred_date" className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gold focus:border-transparent" /></div>
      <div><label htmlFor="message" className="block text-sm font-medium text-navy mb-1">Additional Instructions</label><textarea id="message" name="message" rows={4} className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gold focus:border-transparent" placeholder="Any special requests or details..." /></div>
      <button type="submit" className="w-full btn-primary">Continue to WhatsApp</button>
      <p className="text-xs text-gray-500 text-center">Your enquiry details will be prepared in WhatsApp so you can review and send them directly to PrimeTouch Solutions. The message is not sent until you press Send in WhatsApp.</p>
    </form>
  );
}
