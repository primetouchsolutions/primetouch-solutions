export const siteConfig = {
  name: "PrimeTouch Solutions",
  slogan: "Excellence in Every Touch.",
  location: "Sokoto, Sokoto State, Nigeria",
  phone: "+234 813 248 1687",
  phoneDial: "+2348132481687",
  whatsapp: "2348132481687",
  email: "",
  hours: "Contact us for current availability",
  formspreeEndpoint: "",
  serviceAreas: ["Sokoto Metropolis", "Nearby areas by arrangement"],
  pricingNote: "Prices depend on the service, quantity and location. Message us for a clear, tailored quote before confirming your booking.",
};
