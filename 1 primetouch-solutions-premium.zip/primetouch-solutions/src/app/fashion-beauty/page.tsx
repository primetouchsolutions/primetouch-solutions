import type { Metadata } from "next";
import { siteConfig } from "@/lib/config";

export const metadata: Metadata = {
  title: "Fashion, Clothing & Cosmetics",
  description: "Explore fashion, clothing and cosmetics enquiries from PrimeTouch Solutions in Sokoto, Nigeria. Ask about products and order through WhatsApp.",
};

const categories = [
  { icon: "✦", title: "Fashion & Clothing", text: "Ask us about clothing options, sizes, styles and current availability." },
  { icon: "✧", title: "Cosmetics & Beauty", text: "Enquire about cosmetic and beauty products and confirm details before ordering." },
  { icon: "♡", title: "Personalised Enquiries", text: "Tell us what you are looking for and we will respond with the information available." },
];

export default function FashionBeautyPage() {
  const message = encodeURIComponent("Hello PrimeTouch Solutions, I would like to enquire about fashion, clothing or cosmetics products. Please share current options and prices.");
  return (
    <>
      <section className="bg-navy text-white">
        <div className="max-w-6xl mx-auto section-padding text-center">
          <p className="text-gold uppercase tracking-[0.2em] text-sm font-semibold mb-3">Style & self-care</p>
          <h1 className="text-4xl md:text-5xl font-bold mb-5">Fashion, Clothing & Cosmetics</h1>
          <p className="text-gray-200 max-w-2xl mx-auto mb-8">Discover your next fashion or beauty find with PrimeTouch Solutions. Contact us to ask about current products, availability and prices.</p>
          <a href={`https://wa.me/${siteConfig.whatsapp}?text=${message}`} target="_blank" rel="noopener noreferrer" className="btn-gold">Browse & Order on WhatsApp</a>
        </div>
      </section>
      <section className="section-padding">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-3 gap-6">
            {categories.map((category) => <article key={category.title} className="rounded-2xl border border-gray-200 p-7 shadow-sm"><div className="text-3xl text-gold mb-4">{category.icon}</div><h2 className="text-xl font-bold text-navy mb-3">{category.title}</h2><p className="text-gray-600">{category.text}</p></article>)}
          </div>
          <div className="bg-gray-50 rounded-2xl p-7 md:p-10 mt-10 grid md:grid-cols-2 gap-6 items-center"><div><h2 className="text-2xl font-bold text-navy mb-3">How ordering works</h2><ol className="list-decimal pl-5 space-y-2 text-gray-600"><li>Message us with the product or style you are interested in.</li><li>We will confirm available options and prices.</li><li>Agree on payment, collection or delivery details directly with us.</li></ol></div><div className="md:text-right"><p className="text-gray-600 mb-4">Product photos, stock and prices may change. Please confirm details before making payment.</p><a href={`https://wa.me/${siteConfig.whatsapp}?text=${message}`} target="_blank" rel="noopener noreferrer" className="btn-primary">Ask About Products</a></div></div>
        </div>
      </section>
    </>
  );
}
