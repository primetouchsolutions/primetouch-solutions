import Link from "next/link";
import { siteConfig } from "@/lib/config";

export const metadata = {
  title: "Home & Office Cleaning Services in Sokoto",
  description:
    "Professional home cleaning and office cleaning services in Sokoto Metropolis. Reliable, thorough and locally focused.",
};

export default function CleaningPage() {
  return (
    <div className="section-padding max-w-4xl mx-auto">
      <h1 className="text-3xl md:text-4xl font-bold text-navy mb-4">
        Home & Office Cleaning in Sokoto
      </h1>
      <p className="text-lg text-gray-600 mb-8">
        Clean, organised spaces for homes and workplaces across Sokoto Metropolis.
      </p>

      <div className="space-y-8">
        <section>
          <h2 className="text-xl font-semibold text-navy mb-2">Home Cleaning</h2>
          <p className="text-gray-600">
            Regular or one-off cleaning for residential properties. We focus on thorough 
            work that leaves your home fresh and tidy. Scope can be tailored to your needs 
            (general cleaning, deep clean, specific rooms, etc.).
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold text-navy mb-2">Office Cleaning</h2>
          <p className="text-gray-600">
            Professional cleaning for small offices, shops and commercial spaces. 
            Flexible scheduling to minimise disruption to your business.
          </p>
        </section>
      </div>

      <div className="mt-10 p-5 bg-gray-50 rounded-lg border border-gray-100">
        <p className="text-sm text-gray-600">
          <strong>Service area:</strong> Sokoto Metropolis and surrounding areas 
          (subject to confirmation). Tell us your location when you enquire.
        </p>
      </div>

      <div className="mt-8 flex flex-col sm:flex-row gap-4">
        <Link href="/contact" className="btn-primary">
          Request Cleaning Quote
        </Link>
        <a
          href={`https://wa.me/${siteConfig.whatsapp}`}
          target="_blank"
          rel="noopener noreferrer"
          className="btn-gold"
        >
          Chat on WhatsApp
        </a>
      </div>
    </div>
  );
}
