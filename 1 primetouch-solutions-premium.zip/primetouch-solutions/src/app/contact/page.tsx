import BookingForm from "@/components/BookingForm";
import { siteConfig } from "@/lib/config";

export const metadata = {
  title: "Contact Us / Book a Service – Sokoto",
  description:
    "Enquire about laundry, cleaning, consultancy, fashion and beauty services in Sokoto. Contact PrimeTouch Solutions via WhatsApp or phone.",
};

export default function ContactPage() {
  return (
    <div className="section-padding max-w-6xl mx-auto">
      <h1 className="text-3xl md:text-4xl font-bold text-navy mb-2">
        Contact Us / Book a Service
      </h1>
      <p className="text-gray-600 mb-10">
        Fill the form below or reach us directly. We respond as quickly as possible during business hours.
      </p>

      <div className="grid lg:grid-cols-2 gap-12">
        {/* Form */}
        <div>
          <h2 className="text-xl font-semibold text-navy mb-4">Send an Enquiry</h2>
          <BookingForm />
        </div>

        {/* Contact details */}
        <div>
          <h2 className="text-xl font-semibold text-navy mb-4">Direct Contact</h2>
          <div className="bg-gray-50 rounded-xl p-6 space-y-4">
            <div>
              <p className="text-sm text-gray-500">Phone</p>
              <a className="font-medium hover:text-gold" href={`tel:${siteConfig.phone}`}>{siteConfig.phone}</a>
            </div>
            <div>
              <p className="text-sm text-gray-500">WhatsApp</p>
              <a
                href={`https://wa.me/${siteConfig.whatsapp}`}
                target="_blank"
                rel="noopener noreferrer"
                className="font-medium text-green-600 hover:underline"
              >
                Chat with us on WhatsApp
              </a>
            </div>
            <div>
              <p className="text-sm text-gray-500">Email</p>
              <p className="font-medium">Email available on request</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Business Hours</p>
              <p className="font-medium">{siteConfig.hours}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Service Area</p>
              <p className="font-medium">{siteConfig.location}</p>
              <p className="text-sm text-gray-500 mt-1">
                Surrounding areas subject to confirmation
              </p>
            </div>
          </div>

          <div className="mt-6 p-4 bg-navy text-white rounded-lg text-sm">
            <p>
              Prefer WhatsApp? Click the green button at the bottom right of any page 
              or use the link above. It is often the fastest way to get a reply.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
