import Link from "next/link";
import { siteConfig } from "@/lib/config";

export const metadata = {
  title: "About Us – PrimeTouch Solutions Sokoto",
  description: "Learn about PrimeTouch Solutions – providing laundry, cleaning and business support services in Sokoto Metropolis.",
};

export default function AboutPage() {
  return (
    <div className="section-padding max-w-3xl mx-auto">
      <h1 className="text-3xl md:text-4xl font-bold text-navy mb-6">About PrimeTouch Solutions</h1>
      
      <div className="space-y-6 text-gray-700">
        <p>
          PrimeTouch Solutions is a Sokoto-based business focused on delivering reliable 
          laundry, cleaning and practical business support services to residents and 
          organisations in Sokoto Metropolis.
        </p>
        <p>
          Our guiding principle is simple: <strong className="text-navy">{siteConfig.slogan}</strong>
        </p>
        <p>
          We understand the importance of trust, clear communication and consistent quality. 
          Whether you need carefully handled laundry, a clean home or office, or everyday 
          administrative support, we aim to make the process straightforward.
        </p>
        <p>
          We currently serve Sokoto Metropolis and are happy to discuss nearby areas. 
          All service availability (especially pickup & delivery) is confirmed based on 
          your specific location.
        </p>
      </div>

      <div className="mt-10">
        <Link href="/contact" className="btn-primary">
          Get in Touch
        </Link>
      </div>
    </div>
  );
}
