import Link from "next/link";
import { siteConfig } from "@/lib/config";

export const metadata = {
  title: "Business Support & Consultancy Services in Sokoto",
  description:
    "Practical business support, administrative assistance and basic planning services for small businesses in Sokoto.",
};

export default function ConsultancyPage() {
  return (
    <div className="section-padding max-w-4xl mx-auto">
      <h1 className="text-3xl md:text-4xl font-bold text-navy mb-4">
        Consultancy & Business Support
      </h1>
      <p className="text-lg text-gray-600 mb-8">
        Practical help for small businesses and individuals in Sokoto who need 
        administrative and organisational support.
      </p>

      <div className="space-y-6">
        <section>
          <h2 className="text-xl font-semibold text-navy">What we can help with</h2>
          <ul className="list-disc list-inside text-gray-600 space-y-2 mt-3">
            <li>Basic business planning and simple action plans</li>
            <li>Document preparation and formatting</li>
            <li>Administrative support and organisation</li>
            <li>General business process guidance for small operations</li>
          </ul>
        </section>

        <div className="bg-amber-50 border border-amber-200 rounded-lg p-5">
          <p className="text-sm text-amber-900">
            <strong>Important:</strong> Services requiring specialised professional 
            qualifications (e.g. legal, accounting, or regulated advisory work) are 
            subject to confirmation and may involve referral to appropriately qualified partners. 
            We focus on practical, everyday business support.
          </p>
        </div>
      </div>

      <div className="mt-10 flex flex-col sm:flex-row gap-4">
        <Link href="/contact" className="btn-primary">
          Discuss Your Needs
        </Link>
        <a
          href={`https://wa.me/${siteConfig.whatsapp}`}
          target="_blank"
          rel="noopener noreferrer"
          className="btn-gold"
        >
          Chat on WhatsApp
        </a>
      </div>
    </div>
  );
}
