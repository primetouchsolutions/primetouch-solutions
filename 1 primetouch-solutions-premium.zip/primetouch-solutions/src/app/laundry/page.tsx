import Link from "next/link";
import { siteConfig } from "@/lib/config";

export const metadata = {
  title: "Laundry & Dry Cleaning Services in Sokoto",
  description:
    "Professional laundry services and dry cleaning in Sokoto Metropolis. Pickup and delivery available. Contact PrimeTouch Solutions today.",
};

export default function LaundryPage() {
  return (
    <div className="section-padding max-w-4xl mx-auto">
      <h1 className="text-3xl md:text-4xl font-bold text-navy mb-4">
        Laundry & Dry Cleaning Services in Sokoto
      </h1>
      <p className="text-lg text-gray-600 mb-8">
        Reliable laundry care for individuals, families and businesses across Sokoto Metropolis.
      </p>

      <div className="prose prose-navy max-w-none space-y-6">
        <section>
          <h2 className="text-xl font-semibold text-navy">Laundry Services</h2>
          <p>
            We handle everyday washing, drying and ironing with care. Suitable for clothing, 
            bedding and other washable items. Service is available within Sokoto Metropolis 
            and surrounding areas subject to confirmation.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold text-navy">Dry Cleaning</h2>
          <p>
            Specialist dry cleaning is arranged through a trusted third-party partner where 
            necessary. Delicate fabrics and items that require professional dry cleaning 
            are handled carefully.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold text-navy">Pickup & Delivery</h2>
          <p>
            Laundry pickup and delivery is available subject to service-area confirmation. 
            Contact us with your location to confirm availability and timing.
          </p>
        </section>
      </div>

      <div className="mt-10 flex flex-col sm:flex-row gap-4">
        <Link href="/contact" className="btn-primary">
          Book Laundry Service
        </Link>
        <a
          href={`https://wa.me/${siteConfig.whatsapp}?text=${encodeURIComponent("Hello, I need laundry / dry cleaning services.")}`}
          target="_blank"
          rel="noopener noreferrer"
          className="btn-gold"
        >
          Chat on WhatsApp
        </a>
      </div>
    </div>
  );
}
