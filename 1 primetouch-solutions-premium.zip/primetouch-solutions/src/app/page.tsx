import Link from "next/link";
import { siteConfig } from "@/lib/config";

const services = [
  { number: "01", icon: "✦", title: "Laundry & Dry Cleaning", text: "Thoughtful garment care, washing, ironing and dry-cleaning enquiries—handled with care.", href: "/laundry", tag: "Care for every garment" },
  { number: "02", icon: "⌂", title: "Home & Office Cleaning", text: "Fresh, welcoming spaces with cleaning support tailored to your home or workplace.", href: "/cleaning", tag: "A cleaner kind of comfort" },
  { number: "03", icon: "↗", title: "Consultancy Services", text: "Practical guidance and business support to help you approach your next step with clarity.", href: "/consultancy", tag: "Ideas into action" },
  { number: "04", icon: "◈", title: "Fashion & Clothing", text: "Explore style options and ask us about available clothing, selections and orders.", href: "/fashion-beauty", tag: "Find your everyday style" },
  { number: "05", icon: "✧", title: "Cosmetics & Beauty", text: "Discover beauty and personal-care picks, with easy ordering enquiries through WhatsApp.", href: "/fashion-beauty", tag: "Your beauty, your way" },
];

const wa = `https://wa.me/${siteConfig.whatsapp}?text=${encodeURIComponent("Hello PrimeTouch Solutions, I would like to make an enquiry.")}`;

export default function HomePage() {
  return (
    <>
      <section className="hero-shell">
        <div className="hero-orb hero-orb-one" aria-hidden="true" />
        <div className="hero-orb hero-orb-two" aria-hidden="true" />
        <div className="hero-inner">
          <div className="hero-copy">
            <div className="eyebrow eyebrow-light"><span className="eyebrow-line" /> YOUR EVERYDAY PARTNER IN SOKOTO</div>
            <h1>Life feels better<br />with the <em>right touch.</em></h1>
            <p className="hero-lede">From beautifully cared-for clothes and refreshed spaces to style, beauty and business support—one trusted name, many thoughtful solutions.</p>
            <div className="hero-actions">
              <Link href="/contact" className="button button-gold">Explore our services <span aria-hidden="true">↗</span></Link>
              <a href={wa} target="_blank" rel="noreferrer" className="button button-glass"><span className="whatsapp-dot">◉</span> Chat on WhatsApp</a>
            </div>
            <div className="hero-note"><span className="note-check">✓</span> Personal service. Clear communication. Quality in every detail.</div>
          </div>
          <div className="hero-visual" aria-label="PrimeTouch Solutions service highlights">
            <div className="visual-frame">
              <div className="visual-topline"><span>PRIMETOUCH</span><span>EST. WITH CARE</span></div>
              <div className="visual-monogram">P<span>✦</span>T</div>
              <div className="visual-caption"><span>THE ART OF EVERYDAY CARE</span><strong>Excellence in<br />Every Touch.</strong></div>
              <div className="visual-stamp">QUALITY<br />FIRST</div>
            </div>
            <div className="floating-card floating-card-top"><span className="floating-icon">✧</span><span><b>One trusted partner</b><small>Five service divisions</small></span></div>
            <div className="floating-card floating-card-bottom"><span className="status-dot"/><span><b>Based in Sokoto</b><small>Here to help you</small></span></div>
          </div>
        </div>
        <div className="hero-bottom"><span>CARE THAT FITS YOUR LIFE</span><span className="hero-bottom-line"/><span>SCROLL TO DISCOVER ↓</span></div>
      </section>

      <section className="trust-strip" aria-label="Our approach">
        <div><span className="trust-symbol">✳</span><span><b>Thoughtful service</b><small>We listen before we recommend.</small></span></div>
        <div><span className="trust-symbol">◇</span><span><b>Convenient enquiries</b><small>Contact us online or on WhatsApp.</small></span></div>
        <div><span className="trust-symbol">✦</span><span><b>Many needs, one place</b><small>Everyday solutions under one brand.</small></span></div>
      </section>

      <section className="section-wrap services-section">
        <div className="section-heading">
          <div><div className="eyebrow"><span className="eyebrow-line"/> WHAT WE DO</div><h2>Good service.<br /><em>Thoughtfully delivered.</em></h2></div>
          <p>Life is busy enough. We bring useful services together to make everyday tasks and bigger plans feel a little easier.</p>
        </div>
        <div className="services-grid">
          {services.map((service) => <article className="service-tile" key={service.number}>
            <div className="tile-top"><span className="tile-icon">{service.icon}</span><span className="tile-number">{service.number}</span></div>
            <div className="tile-tag">{service.tag}</div>
            <h3>{service.title}</h3><p>{service.text}</p>
            <Link href={service.href} className="tile-link">Discover more <span aria-hidden="true">↗</span></Link>
          </article>)}
        </div>
      </section>

      <section className="promise-section">
        <div className="promise-mark" aria-hidden="true">✦</div>
        <div className="promise-content"><div className="eyebrow eyebrow-light"><span className="eyebrow-line"/> THE PRIMETOUCH PROMISE</div><h2>Small details.<br /><em>A difference you can feel.</em></h2><p>We believe great service starts with understanding what matters to you. Tell us what you need, and we’ll help you find the right next step—without the guesswork.</p><Link href="/about" className="text-link-light">Get to know us <span>→</span></Link></div>
        <div className="promise-side"><div className="promise-quote">“</div><p>Excellence isn’t just what we do. It’s how we do it.</p><span>PRIMETOUCH SOLUTIONS</span></div>
      </section>

      <section className="cta-section">
        <div><div className="eyebrow"><span className="eyebrow-line"/> LET’S MAKE IT SIMPLE</div><h2>What can we help you<br /><em>take care of today?</em></h2><p>Tell us what you’re looking for. We’ll respond and help you work out the details.</p></div>
        <div className="cta-actions"><Link href="/contact" className="button button-dark">Make an enquiry <span>↗</span></Link><a href={wa} target="_blank" rel="noreferrer" className="cta-phone">Prefer WhatsApp? <b>Start a chat →</b></a><div className="cta-location">⌖ &nbsp; {siteConfig.location}</div></div>
      </section>
    </>
  );
}
