import Link from "next/link";
import { siteConfig } from "@/lib/config";

export const metadata = {
  title: "Pricing – Laundry, Cleaning & Support in Sokoto",
  description: "Example pricing for PrimeTouch Solutions services in Sokoto. Request a personalised quote for accurate rates.",
};

export default function PricingPage() {
  return (
    <div className="section-padding max-w-5xl mx-auto">
      <h1 className="text-3xl md:text-4xl font-bold text-navy mb-4">Pricing</h1>
      <p className="text-gray-600 mb-6">{siteConfig.pricingNote}</p>

      <div className="overflow-x-auto">
        <table className="w-full border-collapse bg-white shadow-sm rounded-lg overflow-hidden">
          <thead>
            <tr className="bg-navy text-white">
              <th className="text-left p-4">Service</th>
              <th className="text-left p-4">Example Starting Point</th>
              <th className="text-left p-4">Notes</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            <tr>
              <td className="p-4 font-medium">Laundry (per load / kg)</td>
              <td className="p-4">Request a Quote</td>
              <td className="p-4 text-sm text-gray-600">Depends on volume & items</td>
            </tr>
            <tr className="bg-gray-50">
              <td className="p-4 font-medium">Dry Cleaning</td>
              <td className="p-4">Request a Quote</td>
              <td className="p-4 text-sm text-gray-600">Via specialist partner</td>
            </tr>
            <tr>
              <td className="p-4 font-medium">Home Cleaning (per session)</td>
              <td className="p-4">Request a Quote</td>
              <td className="p-4 text-sm text-gray-600">Size & scope dependent</td>
            </tr>
            <tr className="bg-gray-50">
              <td className="p-4 font-medium">Office Cleaning</td>
              <td className="p-4">Request a Quote</td>
              <td className="p-4 text-sm text-gray-600">Custom quotation</td>
            </tr>
            <tr>
              <td className="p-4 font-medium">Pickup & Delivery</td>
              <td className="p-4">Subject to location</td>
              <td className="p-4 text-sm text-gray-600">Confirm with us</td>
            </tr>
            <tr className="bg-gray-50">
              <td className="p-4 font-medium">Consultancy / Support</td>
              <td className="p-4">Request a Quote</td>
              <td className="p-4 text-sm text-gray-600">Based on scope of work</td>
            </tr>
          </tbody>
        </table>
      </div>

      <div className="mt-10 text-center">
        <Link href="/contact" className="btn-primary">
          Request Your Personalised Quote
        </Link>
      </div>
    </div>
  );
}
