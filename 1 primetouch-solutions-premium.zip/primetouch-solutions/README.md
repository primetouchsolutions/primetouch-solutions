# PrimeTouch Solutions Website

Professional website for **PrimeTouch Solutions** – Laundry, Cleaning & Business Support services in Sokoto Metropolis, Nigeria.

**Slogan:** Excellence in Every Touch.

## Quick Start (Beginners)

### 1. Install Node.js
Download and install the LTS version from: https://nodejs.org

### 2. Install dependencies
Open a terminal in this folder and run:

```bash
npm install
```

### 3. Run locally
```bash
npm run dev
```

Open http://localhost:3000 in your browser.

### 4. Important: Update your details
Open `src/lib/config.ts` and replace:

- `phone`
- `whatsapp` (numbers only, no + or spaces, e.g. 2348031234567)
- `email`
- `formspreeEndpoint` (see Formspree section below)

## Formspree Setup (Free Contact Form)

1. Go to https://formspree.io and create a free account.
2. Create a new form.
3. Copy the endpoint (looks like `https://formspree.io/f/xxxxxx`).
4. Paste it into `src/lib/config.ts` as `formspreeEndpoint`.

Form submissions will be emailed to the address you registered with Formspree.

## Deploy for Free (Vercel)

1. Create a free account at https://vercel.com (you can sign in with GitHub).
2. Push this project to a free GitHub repository, **or** use the Vercel dashboard to import the folder.
3. Click **Deploy**.
4. You will get a free URL (e.g. `primetouch-solutions.vercel.app`).

### Custom Domain (Optional)
In Vercel → Project → Settings → Domains, add your domain and follow the DNS instructions.  
Typical cost: ₦5,000–15,000 per year.

## Changing Content

| What to change          | File to edit                          |
|-------------------------|---------------------------------------|
| Phone, WhatsApp, email, hours, Formspree | `src/lib/config.ts`              |
| Home page text          | `src/app/page.tsx`                    |
| Laundry page            | `src/app/laundry/page.tsx`            |
| Cleaning page           | `src/app/cleaning/page.tsx`           |
| Consultancy page        | `src/app/consultancy/page.tsx`        |
| Pricing table           | `src/app/pricing/page.tsx`            |
| About page              | `src/app/about/page.tsx`              |
| Contact page            | `src/app/contact/page.tsx`            |

## Testing Checklist

- [ ] WhatsApp button opens the correct chat
- [ ] Contact form submits and you receive the email
- [ ] Site looks good on mobile (use browser DevTools)
- [ ] All “Book a Service” buttons go to the contact page
- [ ] No placeholder text remains in `config.ts`

## Costs

| Item              | Cost              |
|-------------------|-------------------|
| Hosting (Vercel)  | Free              |
| Formspree         | Free tier         |
| Domain (optional) | ₦5k–15k / year    |
| **Total possible**| **₦0**            |

## Support Notes

- No online payments included (to keep costs and complexity low).
- Dry cleaning is handled via a third-party partner (as stated on the site).
- All example prices are clearly marked as unconfirmed.
- No invented testimonials, awards or addresses.

Built for a maximum business startup budget of ₦200,000 – this website can launch at zero cost.


## PrimeTouch Solutions customisation notes

- Business location set to Sokoto, Nigeria.
- Business phone: 08132481687.
- WhatsApp contact: +2348132481687.
- Added Fashion & Beauty page for fashion, clothing and cosmetics enquiries. Orders are initiated through WhatsApp; customers should confirm current stock, pricing, payment and delivery details directly.
- Booking form opens WhatsApp with the enquiry details. The customer must press Send in WhatsApp to submit the enquiry.
- Before launch, review all service descriptions and sample pricing. Connect a custom domain when ready.

## Run locally

Install Node.js (LTS), then from this folder run `npm install` and `npm run dev`. Open the local address shown in the terminal. To create a production build, run `npm run build`.
